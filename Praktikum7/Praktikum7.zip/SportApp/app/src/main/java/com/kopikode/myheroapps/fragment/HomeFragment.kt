package com.kopikode.myheroapps.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.kopikode.myheroapps.DetailMovieActivity
import com.kopikode.myheroapps.Movie
import com.kopikode.myheroapps.MovieAdapter
import com.kopikode.myheroapps.R

class HomeFragment : Fragment() {

    companion object {
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    private lateinit var adapter: MovieAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var movieArrayList: ArrayList<Movie>

    lateinit var image: Array<Int>
    lateinit var title: Array<String>
    lateinit var descriptions: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dataInitialize()
        val layoutManager = LinearLayoutManager(context)
        recyclerView = view.findViewById(R.id.rv_movie)
        recyclerView.layoutManager = layoutManager
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = MovieAdapter(movieArrayList){
            val intent = Intent(context,DetailMovieActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)
        }
    }
    private fun dataInitialize() {
        movieArrayList = arrayListOf<Movie>()

        image = arrayOf(
            R.drawable.arema,
            R.drawable.bali,
            R.drawable.bhayangkara,
            R.drawable.borneo,
            R.drawable.dewa,
            R.drawable.madura,
            R.drawable.persebaya,
            R.drawable.persib,
            R.drawable.persija,
            R.drawable.persik,
            R.drawable.persikabo,
            R.drawable.persis,
            R.drawable.persita,
            R.drawable.barito,
            R.drawable.psis,
            R.drawable.psm,
            R.drawable.pss,
            R.drawable.rans,
            )

        title = arrayOf(
            getString(R.string.Arema),
            getString(R.string.bali),
            getString(R.string.bhayangkara),
            getString(R.string.borneo),
            getString(R.string.dewa),
            getString(R.string.madura),
            getString(R.string.persebaya),
            getString(R.string.persib),
            getString(R.string.persija),
            getString(R.string.persik),
            getString(R.string.persikabo),
            getString(R.string.persis),
            getString(R.string.persita),
            getString(R.string.barito),
            getString(R.string.psis),
            getString(R.string.psm),
            getString(R.string.pss),
            getString(R.string.rans),
        )
        descriptions = arrayOf(
            getString(R.string.singo),
            getString(R.string.serdadu),
            getString(R.string.guardian),
            getString(R.string.pesut),
            getString(R.string.tangsel),
            getString(R.string.sape),
            getString(R.string.baju),
            getString(R.string.maung),
            getString(R.string.macan),
            getString(R.string.jabaya),
            getString(R.string.padjajaran),
            getString(R.string.sambernyawa),
            getString(R.string.cisadane),
            getString(R.string.antasari),
            getString(R.string.mahesa),
            getString(R.string.juku),
            getString(R.string.elja),
            getString(R.string.prestige),
        )
        for (i in image.indices) {

            val movie = Movie(image[i],title[i], descriptions[i])
            movieArrayList.add(movie)
        }
    }
}