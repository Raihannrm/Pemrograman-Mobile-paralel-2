package com.kopikode.myheroapps.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.kopikode.myheroapps.DetailMovieActivity
import com.kopikode.myheroapps.Movie
import com.kopikode.myheroapps.MovieAdapter
import com.kopikode.myheroapps.R

class SubscriptionFragment : Fragment() {
    companion object {
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    private lateinit var adapter: MovieAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var movieArrayList: ArrayList<Movie>

    lateinit var image: Array<Int>
    lateinit var title: Array<String>
    lateinit var descriptions: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_subscription, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dataInitialize()
        val layoutManager = LinearLayoutManager(context)
        recyclerView = view.findViewById(R.id.rv_movie)
        recyclerView.layoutManager = layoutManager
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = MovieAdapter(movieArrayList){
            val intent = Intent(context, DetailMovieActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)
        }
    }

    private fun dataInitialize() {
        movieArrayList = arrayListOf<Movie>()

        image = arrayOf(
            R.drawable.bucks,
            R.drawable.cavaliers,
            R.drawable.celtics,
            R.drawable.dalas,
            R.drawable.denver,
            R.drawable.gsw,
            R.drawable.hornets,
            R.drawable.lakers,
            R.drawable.miami,
            R.drawable.pelicans,
            R.drawable.rokets,
            R.drawable.spurs,
            R.drawable.thunder,
            R.drawable.utah,
            )
        title = arrayOf(
            getString(R.string.bucks),
            getString(R.string.cavaliers),
            getString(R.string.celtics),
            getString(R.string.dalas),
            getString(R.string.denver),
            getString(R.string.gsw),
            getString(R.string.hornets),
            getString(R.string.lakers),
            getString(R.string.miami),
            getString(R.string.pelicans),
            getString(R.string.rokets),
            getString(R.string.spurs),
            getString(R.string.thunder),
            getString(R.string.utah),
        )
        descriptions = arrayOf(
            getString(R.string.bucks),
            getString(R.string.cavaliers),
            getString(R.string.celtics),
            getString(R.string.dalas),
            getString(R.string.denver),
            getString(R.string.gsw),
            getString(R.string.hornets),
            getString(R.string.lakers),
            getString(R.string.miami),
            getString(R.string.pelicans),
            getString(R.string.rokets),
            getString(R.string.spurs),
            getString(R.string.thunder),
            getString(R.string.utah),
        )
        for (i in image.indices) {

            val movie = Movie(image[i],title[i], descriptions[i])
            movieArrayList.add(movie)
        }
    }
}