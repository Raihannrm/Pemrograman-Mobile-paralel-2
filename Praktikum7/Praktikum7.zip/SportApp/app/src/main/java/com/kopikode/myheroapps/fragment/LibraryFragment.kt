package com.kopikode.myheroapps.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.kopikode.myheroapps.DetailMovieActivity
import com.kopikode.myheroapps.Movie
import com.kopikode.myheroapps.MovieAdapter
import com.kopikode.myheroapps.R

class LibraryFragment : Fragment() {
    companion object {
        const val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    private lateinit var adapter: MovieAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var movieArrayList: ArrayList<Movie>

    private lateinit var image: Array<Int>
    private lateinit var title: Array<String>
    private lateinit var descriptions: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_library, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dataInitialize()
        val layoutManager = LinearLayoutManager(context)
        recyclerView = view.findViewById(R.id.rv_movie)
        recyclerView.layoutManager = layoutManager
        recyclerView.setHasFixedSize(true)
        adapter = MovieAdapter(movieArrayList) { movie ->
            val intent = Intent(context, DetailMovieActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, movie)
            startActivity(intent)
        }
        recyclerView.adapter = adapter
    }

    private fun dataInitialize() {
        movieArrayList = arrayListOf()

        image = arrayOf(
            R.drawable.aerowolf,
            R.drawable.alter,
            R.drawable.aura,
            R.drawable.black,
            R.drawable.boom,
            R.drawable.btr,
            R.drawable.burmese,
            R.drawable.evos,
            R.drawable.foxy,
            R.drawable.geek,
            R.drawable.onic,
            R.drawable.rrq,
            R.drawable.tm,
            R.drawable.venom,
            R.drawable.viver
        )
        title = arrayOf(
            getString(R.string.aero),
            getString(R.string.ae),
            getString(R.string.aura),
            getString(R.string.black),
            getString(R.string.boom),
            getString(R.string.btr),
            getString(R.string.burmese),
            getString(R.string.evos),
            getString(R.string.foxy),
            getString(R.string.geek),
            getString(R.string.onic),
            getString(R.string.rrq),
            getString(R.string.tm),
            getString(R.string.venom),
            getString(R.string.viver)
        )
        descriptions = arrayOf(
            getString(R.string.aero_desc),
            getString(R.string.ae_desc),
            getString(R.string.aura_desc),
            getString(R.string.black_desc),
            getString(R.string.boom_desc),
            getString(R.string.btr_desc),
            getString(R.string.burmese_desc),
            getString(R.string.evos_desc),
            getString(R.string.foxy_desc),
            getString(R.string.geek_desc),
            getString(R.string.onic_desc),
            getString(R.string.rrq_desc),
            getString(R.string.tm_desc),
            getString(R.string.venom_desc),
            getString(R.string.viver_desc)
        )
        for (i in image.indices) {
            val movie = Movie(image[i], title[i], descriptions[i])
            movieArrayList.add(movie)
        }
    }
}